import React, { useEffect, useState } from "react";
import {
  Box,
  Button,
  Flex,
  Text,
  Input,
  Slider,
  SliderTrack,
  SliderFilledTrack,
  SliderThumb,
  SliderMark,
} from "@open-pioneer/chakra-integration";
import { MapAnchor, MapContainer, useMapModel } from "@open-pioneer/map";
import { ScaleBar } from "@open-pioneer/scale-bar";
import { InitialExtent, ZoomIn, ZoomOut } from "@open-pioneer/map-navigation";
import { CoordinateViewer } from "@open-pioneer/coordinate-viewer";
import { Geolocation } from "@open-pioneer/geolocation";
import { ScaleViewer } from "@open-pioneer/scale-viewer";
import { MAP_ID } from "./services";
import VectorSource from "ol/source/Vector";
import VectorLayer from "ol/layer/Vector.js";
import GeoJSON from 'ol/format/GeoJSON';
import Style from 'ol/style/Style';
import Fill from 'ol/style/Fill';
import Stroke from 'ol/style/Stroke';
import CircleStyle from 'ol/style/Circle';
import { transform } from 'ol/proj';
import Icon from "ol/style/Icon";
import axios from "axios";

export function MapApp() {
  const [date, setDate] = useState<string>("");
  const [time, setTime] = useState<number>(0); // Initialwert für die Zeit (in Minuten)
  const [loading, setLoading] = useState(false); // Ladezustand
  const [weatherData, setWeatherData] = useState(null); // Wetterdaten

  useEffect(() => {
    setDate("2023-01-01"); 
    setTime(720);
  }, []);

  const { map } = useMapModel(MAP_ID);

  useEffect(() => {
    if (map?.layers) {

      // Maximalen Zoom setzen
    map.olMap.getView().setMaxZoom(19);

    const plannedAreasVectorSource = new VectorSource({
      url: "./img/fahrradzaehl-standorte.geojson",
      format: new GeoJSON({
        dataProjection: "EPSG:4326",
        featureProjection: "EPSG:3857",
      }),
    });

    // VectorLayer mit Fahrrad-Stil
    const plannedAreasLayer = new VectorLayer({
      source: plannedAreasVectorSource 
    });
    // GeoJSON-Layer zur Karte hinzufügen
    map.olMap.addLayer(plannedAreasLayer);

    }
  }, [map]);

  // Funktion, um Minuten in Uhrzeit umzuwandeln (z. B. 90 Minuten => "01:30")
  const formatTime = (minutes: number) => {
    const hours = Math.floor(minutes / 60)
      .toString()
      .padStart(2, "0");
    const mins = (minutes % 60).toString().padStart(2, "0");
    return `${hours}:${mins}`;
  };

  const fetchWeatherData = async () => {
    try {
      setLoading(true);
      const selectedTime = formatTime(time);
      const datetime = `${date}T${selectedTime}:00`; // Kombiniere Datum und Uhrzeit
      const stationId = "01048"; // ID einer Wetterstation, z.B. für Münster

      const response = await axios.get(
        `https://opendata.dwd.de/weather/obs/point/${stationId}/2023/`,
        {
          params: {
            datetime,
          },
        }
      );

      // Parse der Daten
      setWeatherData(response.data);
    } catch (error) {
      console.error("Fehler beim Abrufen der Wetterdaten:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Flex height="100vh" direction="column" overflow="hidden" width="100%">
      {/* Kopfzeile */}
      <Flex
        as="header"
        backgroundColor="gray.100"
        padding={4}
        justifyContent="space-between"
        alignItems="center"
        borderBottom="1px solid"
        borderColor="gray.200"
      >
        <Text fontSize="lg" fontWeight="bold">
          Münster Bicycle Safety Analysis
        </Text>
        <Button variant="link" colorScheme="red">
          Reset Application
        </Button>
      </Flex>

      {/* Inhalt */}
      <Flex
        flex="1"
        direction="column"
        justifyContent="center"
        alignItems="center"
        padding={4}
      >
        {/* Input-Feld und Platz für ein weiteres Element */}
        <Flex width="50%" justifyContent="space-between" mb={4}>
          <Box width="48%">
            <Text mb={2}>Bitte wähle ein Datum:</Text>
            <Input
              type="date"
              value={date || "2023-01-01"}
              min="2023-01-01"
              max="2023-12-31"
              onChange={(e) => setDate(e.target.value)}
            />
            {date && <Text mt={2}>Selected Date: {date}</Text>}
          </Box>
          <Box width="48%">
            {/* Platz für ein weiteres Element */}
            <Text mb={2}>Hier soll das Wetterfeld hin:</Text>
            <Input
              placeholder="Hier könnte etwas stehen"
              onChange={(e) => console.log(e.target.value)}
            />
          </Box>
        </Flex>

        {/* Karte */}
        <Box
          backgroundColor="white"
          borderWidth="2px"
          borderRadius="lg"
          boxShadow="lg"
          overflow="hidden"
          width="70%"
          height="50%"
        >
          <MapContainer mapId={MAP_ID} role="main">
            <MapAnchor position="bottom-right" horizontalGap={10} verticalGap={30}>
              <Flex direction="column" gap={1} padding={1}>
                <Geolocation mapId={MAP_ID} />
                <InitialExtent mapId={MAP_ID} />
                <ZoomIn mapId={MAP_ID} />
                <ZoomOut mapId={MAP_ID} />
              </Flex>
            </MapAnchor>
          </MapContainer>
        </Box>

        {/* Slider für Uhrzeit */}
        <Box mt={4} width="70%">
          <Text mb={2}>Bitte wähle eine Uhrzeit:</Text>
          <Slider
            min={0} // Startwert (Mitternacht)
            max={1440} // Maximale Minuten im Tag (24 Stunden x 60 Minuten)
            step={15} // Schritte in 15-Minuten-Intervallen
            value={time}
            onChange={(value) => setTime(value)}
          >
            {/* Zeige markierte Schritte an */}
            {[0, 180, 360, 540, 720, 900, 1080, 1260, 1440].map((minute) => (
              <SliderMark
                key={minute}
                value={minute}
                mt="2"
                ml="-2.5"
                fontSize="sm"
              >
                {formatTime(minute)}
              </SliderMark>
            ))}
            <SliderTrack>
              <SliderFilledTrack />
            </SliderTrack>
            <SliderThumb />
          </Slider>
          <Text mt={6} textAlign="center">Selected Time: {formatTime(time)}</Text>
        </Box>
      </Flex>
      <Button onClick={fetchWeatherData} isLoading={loading} colorScheme="blue">
          Wetter abrufen
        </Button>
        {weatherData && (
          <Box mt={4} p={4} borderWidth="1px" borderRadius="lg" width="50%">
            <Text fontSize="lg" fontWeight="bold" mb={2}>
              Wetterdaten für {date} um {formatTime(time)}:
            </Text>
            <Text>Temperatur: {weatherData.temperature}°C</Text>
            <Text>Wetter: {weatherData.weather}</Text>
            <Text>Windgeschwindigkeit: {weatherData.windSpeed} m/s</Text>
          </Box>
        )}

      {/* Footer */}
      <Flex
        as="footer"
        role="region"
        gap={3}
        alignItems="center"
        justifyContent="center"
        padding={4}
        borderTop="1px solid"
        borderColor="gray.200"
      >
        <CoordinateViewer mapId={MAP_ID} precision={2} />
        <ScaleBar mapId={MAP_ID} />
        <ScaleViewer mapId={MAP_ID} />
      </Flex>


    </Flex>
  );
}
